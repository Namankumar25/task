-- phpMyAdmin SQL Dump
-- version 5.0.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jul 23, 2021 at 08:23 AM
-- Server version: 10.4.14-MariaDB
-- PHP Version: 7.2.34

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `intern_task`
--

-- --------------------------------------------------------

--
-- Table structure for table `business_staff_members`
--

CREATE TABLE `business_staff_members` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'staff@gmail.com',
  `password` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` enum('active','disabled') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `zoom_active` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `zoom_refresh` longtext COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `expires_in` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zoom_access` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `paypal_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `stripe_token` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `code` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTC',
  `language` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `brand_color` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `date_format` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `time_format` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `business_id` bigint(20) UNSIGNED NOT NULL,
  `smtp_email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `smtp_username` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `smtp_password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `smtp_server` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `smtp_authentication` tinyint(4) NOT NULL DEFAULT 0,
  `protocol` enum('TLS','SSL','STARTTLS') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'TLS',
  `port` int(11) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `profile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(500) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_selected_email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `g_calendar_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `business_staff_members`
--

INSERT INTO `business_staff_members` (`id`, `name`, `email`, `password`, `status`, `zoom_active`, `zoom_refresh`, `expires_in`, `zoom_access`, `paypal_token`, `stripe_token`, `code`, `timezone`, `language`, `brand_color`, `date_format`, `time_format`, `business_id`, `smtp_email`, `smtp_username`, `smtp_password`, `smtp_server`, `smtp_authentication`, `protocol`, `port`, `created_at`, `updated_at`, `deleted_at`, `remember_token`, `email_verified_at`, `profile`, `logo`, `description`, `g_selected_email`, `g_calendar_id`) VALUES
(1, 'Udit Arora', 'staff@gmail.com', '$2y$10$QotfEmJZzU3E4dMQ6IGfbefcQvYlLMevoGNjJPLAbau63Do4T0b1K', 'active', '', '', '2021-07-19 16:08:18', '', '', '', 'gy2rfZw1jl', 'Africa/Dar_es_Salaam', '', '', '', '', 1, '', '', '', '', 0, 'TLS', 0, '2021-07-17 00:54:53', '2021-07-22 05:19:13', NULL, NULL, NULL, NULL, NULL, 'dsasd asd sasdad ad', 'uditarora.ubs@gmail.com', NULL),
(20, 'dummy_2', 'dummy_gmail', '1234', 'active', 'zoom_active', 'zoom_refresh', 'expires_in', 'zoom_access', 'paypal_token', 'stripe_token', '1', 'UTC', 'language', 'sky_blue', 'date_format', 'time_format', 234, 'gmail', 'smtp_username', 'smtp_password', 'smtup_server', 1, 'TLS', 23, '2021-07-14 04:23:44', '2021-07-22 04:23:44', '2021-07-08 04:23:44', 'remember_token', '2021-07-14 04:23:44', NULL, NULL, 'description', 'g_selected', '2');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `business_staff_members`
--
ALTER TABLE `business_staff_members`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `business_staff_members_code_unique` (`code`),
  ADD UNIQUE KEY `business_staff_members_g_selected_email_unique` (`g_selected_email`),
  ADD UNIQUE KEY `business_staff_members_g_calendar_id_unique` (`g_calendar_id`),
  ADD KEY `business_staff_members_business_id_foreign` (`business_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `business_staff_members`
--
ALTER TABLE `business_staff_members`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
