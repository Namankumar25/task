<?php
$hostname = "127.0.0.1";
$username = "root";
$password = "";
$dbname = "<database_name>";

$conn = mysqli_connect($hostname,$username,$password,$dbname);

?>